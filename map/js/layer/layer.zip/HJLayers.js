﻿/*
*图层管理
*/
var HJLayers = {
    map: null,
    /*
    *初始化加载地图
    */
    Init: function (map) {
        this.map = map;
                    
        var clayers = HJConfig.Layers();
        var clayer, layer;
        for (var i = 0; i < clayers.length; i++) {
            clayer = clayers[i];
		
            if (clayer.type == HJLayerType.ArcGISTile) {//arcgis 地图切片服务
                layer = new esri.layers.ArcGISTiledMapServiceLayer(clayer.url);
                layer.id = clayer.name;
                layer.visible = clayer.visible;			     
                HJLayers.map.addLayer(layer);
            } else if (clayer.type == HJLayerType.ArcGISDynamic) {//arcgis 动态地图服务
                layer = new esri.layers.ArcGISDynamicMapServiceLayer(clayer.url);
                layer.id = clayer.name;
                layer.visible = clayer.visible;
                HJLayers.map.addLayer(layer);
            } else if (clayer.type == HJLayerType.ArcGISFeature) {//arcgis 地图矢量要素服务
                layer = new esri.layers.FeatureLayer(clayer.url, {
                    mode: esri.layers.FeatureLayer.MODE_ONDEMAND,
                    outFields: ["*"]
                });
                layer.id = clayer.name;
                layer.visible = clayer.visible;
                layer.infoTemplate = new esri.InfoTemplate(clayer.name + "信息", clayer.attributes);
                HJLayers.map.addLayer(layer);


            } else if (clayer.type == HJLayerType.WebTiledLayer) {
                layer = new esri.layers.WebTiledLayer(clayer.url);
                layer.id = clayer.name;
                layer.visible = clayer.visible;
                HJLayers.map.addLayer(layer);
            } else if (clayer.type == HJLayerType.WFSLayer) {//wfs 地图矢量要素服务
                layer = new esri.layers.WFSLayer(clayer.url);
                layer.id = clayer.name;
                layer.visible = clayer.visible;
                HJLayers.map.addLayer(layer);
            } else if (clayer.type == HJLayerType.WMSLayer) {//wms 地图切片服务
                layer = new esri.layers.WMSLayer(clayer.url);
                layer.id = clayer.name;
                layer.visible = clayer.visible;
                HJLayers.map.addLayer(layer);
            } else if (clayer.type == HJLayerType.WMTSLayer) {//wmts 地图服务

            } else if (clayer.type == HJLayerType.HJGraphicsLayer) {//自定义图层
                layer = new HJGraphicsLayer();
                layer.Init(HJLayers.map, clayer.url, clayer.name, clayer.attributes,clayer.visible);
            }
			if(clayer==undefined){
				return;
			}
			if(clayer.maxScale!=undefined){
				layer.setMaxScale(clayer.maxScale);
			}
			if(clayer.minScale!=undefined){
				layer.setMinScale(clayer.minScale);
			}
			
        }
    },
    /*
    *根据名称获取图层
    */
    GetLayer: function (layerid) {
        return HJLayers.map.getLayer(layerid);
    }
};